
import React from 'react';

const PhoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 0 0 2.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 0 1-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 0 0-1.091-.852H4.5A2.25 2.25 0 0 0 2.25 6.75Z" />
    </svg>
);

const EnvelopeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
    </svg>
);

const contactInfo = {
  phone: '0882277930100',
  whatsapp: '0882277930100',
  email: 'admin@sreak.com',
};

const Contact: React.FC = () => {
  return (
    <section id="kontak" className="bg-brand-dark py-20 sm:py-32">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-brand-white mb-6">Hubungi Kami</h2>
        <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
          Siap untuk memulai proyek Anda? Hubungi kami melalui salah satu cara berikut.
        </p>
        <div className="flex flex-col md:flex-row justify-center items-center gap-8 md:gap-12 mb-16">
          <a href={`tel:+62${contactInfo.phone}`} className="flex items-center space-x-3 text-brand-light-gray hover:text-brand-white transition-colors duration-300 text-lg">
            <PhoneIcon className="w-6 h-6" />
            <span>{contactInfo.phone}</span>
          </a>
          <a href={`mailto:${contactInfo.email}`} className="flex items-center space-x-3 text-brand-light-gray hover:text-brand-white transition-colors duration-300 text-lg">
            <EnvelopeIcon className="w-6 h-6" />
            <span>{contactInfo.email}</span>
          </a>
        </div>
        <p className="text-xl text-brand-white mb-6 font-semibold">
          Hubungi SREAK sekarang melalui WhatsApp!
        </p>
        <a
          href={`https://wa.me/62${contactInfo.whatsapp}?text=Halo%20SREAK,%20saya%20tertarik%20dengan%20layanan%20Anda.`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-green-500 text-white font-bold py-3 px-8 rounded-full hover:bg-green-600 transition-transform duration-300 transform hover:scale-105"
        >
          WhatsApp: {contactInfo.whatsapp}
        </a>
      </div>
    </section>
  );
};

export default Contact;
