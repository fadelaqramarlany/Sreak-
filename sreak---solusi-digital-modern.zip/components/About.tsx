
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="tentang" className="bg-gray-900 py-20 sm:py-32">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl sm:text-4xl font-bold text-brand-white mb-6">Tentang Kami</h2>
            <p className="text-lg text-gray-400 leading-relaxed">
              SREAK berfokus pada layanan digital, pembuatan website, dan solusi online yang sederhana namun efektif. Kami berkomitmen untuk memberikan produk berkualitas tinggi yang modern, responsif, dan mudah diakses, membantu bisnis dan individu mencapai tujuan digital mereka dengan tampilan yang profesional dan fungsionalitas yang handal.
            </p>
          </div>
          <div className="order-1 md:order-2">
            <img 
              src="https://picsum.photos/800/600?grayscale" 
              alt="Tim SREAK sedang bekerja" 
              className="rounded-lg shadow-2xl object-cover w-full h-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
