
import React from 'react';

const CodeBracketIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 6.75 22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3-4.5 16.5" />
    </svg>
);

const PaintBrushIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
    </svg>
);

const WrenchScrewdriverIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17 17.25 21A2.652 2.652 0 0 0 21 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.73-.664 1.193-.816l-2.496 3.03ZM11.42 15.17 7.373 8.169c-.771 2.134-.436 4.57.958 6.006l3.089 3.089Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M7.373 8.169 3.326 12.216c-1.42.432-2.734.02-3.325-1.077l.02-.021c-.596-1.098-.19-2.45.99-3.326l4.046-4.046c.875-.781 2.228-1.187 3.326-.99l.021.02c1.098.596 1.51 1.905 1.077 3.326L7.373 8.169Z" />
    </svg>
);

const ChatBubbleLeftRightIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.72-3.72a1.052 1.052 0 0 0-1.487 0l-3.72 3.72-3.72-3.72a1.052 1.052 0 0 0-1.487 0l-3.72 3.72-1.98-2.193c-.343-.379-1.025-.563-1.488-.328a2.528 2.528 0 0 0-1.487 2.097v-4.286c0-1.136.847-2.1 1.98-2.193l3.72 3.72a1.052 1.052 0 0 0 1.487 0l3.72-3.72 3.72 3.72a1.052 1.052 0 0 0 1.487 0l3.72-3.72Z" />
    </svg>
);

const services = [
  { name: 'Pembuatan Website', icon: CodeBracketIcon, description: 'Membangun website profesional dari awal sesuai kebutuhan Anda.' },
  { name: 'Desain Digital', icon: PaintBrushIcon, description: 'Menciptakan desain visual yang menarik dan modern untuk brand Anda.' },
  { name: 'Maintenance Website', icon: WrenchScrewdriverIcon, description: 'Menjaga website Anda tetap aman, cepat, dan up-to-date.' },
  { name: 'Konsultasi Online', icon: ChatBubbleLeftRightIcon, description: 'Memberikan solusi dan strategi digital untuk mengembangkan bisnis Anda.' },
];

const Services: React.FC = () => {
  return (
    <section id="layanan" className="bg-brand-dark py-20 sm:py-32">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-white mb-4">Layanan Kami</h2>
          <p className="text-lg text-gray-400">
            Kami menyediakan berbagai layanan digital untuk mendukung kesuksesan online Anda.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-brand-gray p-8 rounded-lg text-center transform hover:-translate-y-2 transition-transform duration-300 shadow-lg">
              <div className="flex items-center justify-center h-16 w-16 rounded-full bg-gray-700 mx-auto mb-6">
                <service.icon className="h-8 w-8 text-brand-white" />
              </div>
              <h3 className="text-xl font-bold text-brand-white mb-2">{service.name}</h3>
              <p className="text-gray-400">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
