
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="beranda" className="min-h-screen flex items-center justify-center text-center bg-brand-dark">
      <div className="container mx-auto px-6 py-16">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-extrabold text-brand-white mb-4 tracking-tight">
            SREAK
          </h1>
          <p className="text-xl md:text-2xl text-brand-light-gray mb-8">
            Solusi Digital Modern
          </p>
          <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
            SREAK adalah website yang menyediakan layanan digital dan informasi profesional untuk kebutuhan bisnis dan personal.
          </p>
          <a
            href="https://wa.me/62882277930100?text=Halo%20SREAK,%20saya%20tertarik%20dengan%20layanan%20Anda."
            target="_blank"
            rel="noopener noreferrer"
            className="bg-brand-white text-brand-dark font-bold py-3 px-8 rounded-full hover:bg-brand-light-gray transition-transform duration-300 transform hover:scale-105"
          >
            Hubungi Kami Sekarang
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
